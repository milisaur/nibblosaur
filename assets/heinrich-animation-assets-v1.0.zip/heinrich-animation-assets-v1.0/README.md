# Heinrich Animation Asset Package v1.0

**Project:** Nibblosaur  
**Character:** Heinrich (Nibblesaurus)  
**Status:** Technically normalized prototype; artistic and in-engine validation pending.

## Quick start

Use `spritesheets/128/` for the initial JavaFX prototype. Use `spritesheets/448/` when preserving the original detail matters, and `spritesheets/64/` for a lower-resolution experiment. Every sheet is a genuine RGBA PNG containing 12 equal-sized tiles in a 4-column × 3-row grid. The source files were animated GIFs with misleading `.png` filename extensions; corrected originals are retained in `sources/`.

| Variant | Tile size | Sheet size | Horizontal anchor | Ground boundary |
|---|---:|---:|---:|---:|
| Master | 448 × 448 | 1792 × 1344 | 224 | 376 |
| Recommended prototype | 128 × 128 | 512 × 384 | 64 | 107.43 |
| Micro experiment | 64 × 64 | 256 × 192 | 32 | 53.71 |

Coordinates originate at the upper left of a tile. The ground is a pixel boundary, not a row index; round consistently when rendering. These are canvas sizes, not the creature's bounding dimensions. Keep the viewport and display scale fixed when changing animation states. Do not trim individual frames or fit them independently to their opaque bounds. Disable image smoothing when enlarging sprites for a pixel-art look.

Frame indices run from 0 through 11, left to right, top to bottom. For tile size `s`, the top-left frame position is `((index % 4) * s, (index / 4) * s)` using integer division. Use `animations.json` for machine-readable timing, paths, layout and suggested playback rules.

## Animation library

| Clip | Frames | Time per frame | Total | Game behavior |
|---|---:|---:|---:|---|
| idle | 12 | 180 ms | 2160 ms | Loop |
| walk | 12 | 140 ms | 1680 ms | Loop while moving |
| eat | 12 | 140 ms | 1680 ms | Once, then idle |
| sleep | 12 | 140 ms | 1680 ms | Loop while sleeping |
| happy | 12 | 140 ms | 1680 ms | Once, then idle |
| curious | 12 | 140 ms | 1680 ms | Once, then idle |
| play | 12 | 140 ms | 1680 ms | Once, then idle |

Durations retain the actual source timings. All GIF previews loop for convenient visual inspection; this does not override game playback behavior. Walk is an in-place animation: move Heinrich through the game world separately. Gameplay state and stat changes belong in the game logic rather than the art asset.

## Package layout

- `spritesheets/448/`: seven high-resolution normalized PNG sheets.
- `spritesheets/128/`: seven nearest-neighbor reduced PNG sheets.
- `spritesheets/64/`: seven nearest-neighbor reduced PNG sheets.
- `frames/<animation>/00.png` ... `11.png`: 84 individual 448 px normalized PNG frames.
- `previews/`: seven transparent 224 px animated GIFs.
- `sources/`: seven unchanged source GIFs, renamed to reflect actual format.
- `animations.json`: integration metadata.
- `qa/`: measurements, automated verification, comparison contact sheet and validation report.

## Processing decisions

The source frame size is 362 × 362. A larger shared master canvas gives all frames sufficient room for the creature, hops, tail and effects. The horizontal anchor is constant within each clip, estimated from a neutral pose. One approximate uniform scale per clip improves apparent size continuity relative to idle: idle/eat/sleep 1.00; walk/happy/curious 1.02; play 1.12. Nearest-neighbor sampling preserves hard edges but cannot create genuine native-resolution artwork.

Planted poses were vertically translated using a foreground-component foot estimate, excluding the rightmost prop region when appropriate. Happy's hop/rear uses a fixed floor in its airborne frames. Play retains a fixed scene floor; where the body and pinecone are separately identifiable and do not materially overlap after translation, the body is aligned independently. Contact poses and airborne poses are preserved rather than forcibly flattened. Intentional motion and baked-in effects remain visible.

## Known limitations

- These are generated pixel-style assets, not hand-authored 64 px pixel art. Reduced sheets need an artistic pixel-level pass if strict native pixel art is the target.
- A common canvas and anchor do not guarantee anatomical consistency: plate outlines, eyes, limbs, pose and relative scale vary slightly between generated frames and clips.
- Walk gait, idle seam and action-to-idle transitions still need playback review; sleep does not contain separate lying-down or waking-up clips. No transition frames were invented.
- Leaves, pinecone, attention marks and sleep symbols are embedded in the images; some touch the character and cannot be reliably separated automatically. Play's contact poses retain small ground offsets.
- Alpha is real but binary, inherited from GIF. Original color quantization, outline artifacts and possible color fringes remain; PNG conversion does not restore lost colors. GIF previews also use a palette.
- No JavaFX runtime integration, performance profiling, or final artistic approval has been performed.

The package is suitable for initial engine integration and visual testing, not a claim of final production-art approval.

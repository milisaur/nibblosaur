# Technical validation

## Source diagnosis

All seven sources are readable GIF89a-compatible animated assets with 12 frames of 362 × 362 pixels, binary transparency and infinite preview looping. All source files had `.png` names despite being GIF data. Idle uses 180 ms per frame; all other clips use 140 ms. Every decoded frame contains both fully transparent and fully opaque pixels.

Source neutral/planted floor estimates differed considerably across clips: idle 328–329, walk 298–300, eat 317–318 (excluding the rightmost food region), sleep 317–320, happy first frame 327, curious 296–300, play first creature frame 305 with the prop near 318. These numbers are estimates from connected foreground regions rather than skeletal landmarks. Jump frames were not classified as alignment defects simply because they rose above the floor.

## Normalized output

| Check | Result |
|---|---|
| Seven complete animation sequences | Pass |
| True RGBA PNG sheets | Pass |
| All 252 tiles match expected frame images | Pass |
| All 84 master frame files match sheet tiles | Pass |
| Binary transparency in every tile | Pass |
| No foreground touches any output tile boundary | Pass |
| Seven GIF previews retain 12 frames and source delays | Pass |
| GIF preview alpha masks match expected masks | Pass |
| Common canvas, horizontal anchor and reference floor | Pass; intentional motion and prop contact exceptions documented |
| Exact anatomical consistency and perfect cross-state transitions | Pending visual/in-engine review |
| Native 64 px artwork | Not achieved; 64 px files are derived raster reductions |

The comparison contact sheet shows the normalized 128 px version with a common ground guide. The measurements CSV records original and normalized bounding boxes, connected components, estimated source feet and placement methods. Largest-component bounds may include a touching prop or effect; base offsets are for the full-frame placement, before optional independent creature placement in play. Coordinates and areas are measurements, not proof of anatomical fidelity.

## Clip-specific observations

- Idle: grounding is already stable in the source; the breathing motion is fairly pronounced and the loop seam should be reviewed.
- Walk: source baseline differs from idle, corrected; assess gait and foot sliding in engine.
- Eat: fixed ground; foliage and crumbs are baked in, and the final frame is not identical to idle.
- Sleep: ground normalized; sleep letters are embedded, and there is no start/end transition clip.
- Happy: lift is preserved for the rear/hop; action marks remain embedded.
- Curious: crouching and alert head lift are retained; attention marks remain embedded.
- Play: original character is smaller due to prop composition, so the whole clip receives a uniform scale correction. The pounce and scene floor are preserved; some grounded/contact frames retain small offsets or prop overlap. Review these in engine.

Automated checks establish structural integrity, not the artistic quality of motion. The contact sheet was also visually inspected for obvious clipping and gross cross-clip mismatch. A complete frame-by-frame animation playback review and in-engine test remain outstanding.
